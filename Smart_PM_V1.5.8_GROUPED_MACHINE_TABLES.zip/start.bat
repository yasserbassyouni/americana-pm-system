@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing packages...
  call npm ci
  if errorlevel 1 (
    echo Installation failed. Check the message above.
    pause
    exit /b 1
  )
)
node server.js
pause
